﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Sheet_04___Question_01_part_03
{
    internal class ConvertValues
    {
        public double kilometerTOmeter(double km)
        {
            double meter = km * 1000;
            return meter;
        }
    }
}
